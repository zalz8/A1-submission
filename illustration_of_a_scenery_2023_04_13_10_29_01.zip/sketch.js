function setup() {
  createCanvas(620, 400);
}

function draw() {
  background(0);

  fill(255, 204, 0); 
  noStroke(); 
  ellipse( 60, 60, 100, 100)
 
  
  
 fill(0, 200, 0); 
  rect(0, height - 50, width, 50);
 
  
  fill(139, 69, 19);
  rect(300, 200,20, 150);
  fill(34, 139, 34);
  ellipse(310, 180, 80, 80);
  
  fill(139, 69, 19);
  rect(19, 200,20, 150);
  fill(34, 139, 34);
  ellipse(27, 180, 80, 80);
  
  fill(139, 69, 19);
  rect(410, 200,20, 150);
  fill(34, 139, 34);
  ellipse(420, 180, 80, 80);
  
  fill(139, 69, 19);
  rect(515, 200,20, 150);
  fill(34, 139, 34);
  ellipse(525, 180, 80, 80);
  
  fill('pink')
  triangle(200, 50, 350, 200, 50, 200);
  fill('white');
  rect(50, 200, 300, 150);
  fill('pink');
  rect(150, 250, 100, 100);
  fill('white')
  ellipse(225, 310, 10, 10);
  
  ellipse( 400, 40, 40, 40);
 ellipse( 430, 40, 55, 55);
  ellipse( 460, 40, 40, 40);
  
  ellipse( 540, 100, 40, 40);
 ellipse( 520, 100, 30, 30);
  ellipse( 560, 100, 30, 30);
  
fill(139, 69, 19);
  rect(610, 200,20, 150);
  fill(34, 139, 34);
  ellipse(620, 180, 80, 80);
  

  
}
